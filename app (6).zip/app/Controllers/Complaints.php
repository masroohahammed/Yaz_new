<?php

namespace App\Controllers;

/**
 * FM complaints — maintenance_requests registry with CRUD.
 */
class Complaints extends BaseController
{
  public function index()
  {
    $search = trim((string) $this->request->getGet('search'));
    $rows   = [];

    if ($this->db->tableExists('maintenance_requests')) {
      $builder = $this->db->table('maintenance_requests')
        ->select('id, ticket_number, category, priority, status, created_at')
        ->orderBy('created_at', 'DESC')
        ->limit(200);

      if ($search !== '') {
        $builder->groupStart()
          ->like('ticket_number', $search)
          ->orLike('title', $search)
          ->groupEnd();
      }

      $rows = $builder->get()->getResultArray();
    }

    return view('modules/registry', $this->viewData([
      'title'   => 'Complaints',
      'icon'    => 'bi-exclamation-circle',
      'slug'    => 'complaints',
      'columns' => [
        ['key' => 'ticket_number', 'label' => 'Ticket'],
        ['key' => 'category', 'label' => 'Subject'],
        ['key' => 'priority', 'label' => 'Priority'],
        ['key' => 'status', 'label' => 'Status'],
        ['key' => 'created_at', 'label' => 'Created'],
      ],
      'rows'         => $rows,
      'filters'      => ['search' => $search],
      'tableMissing' => ! $this->db->tableExists('maintenance_requests'),
    ]));
  }

  public function create()
  {
    return view('complaints/form', $this->viewData([
      'title' => 'New Complaint',
      'row'   => [],
      'tenants' => $this->loadTenants(),
      'facilities' => $this->loadFacilities(),
    ]));
  }

  public function store()
  {
    $rules = [
      'category'    => 'required|min_length[3]',
      'description' => 'required',
      'priority'    => 'required',
      'facility_id' => 'required|integer',
    ];
    if (! $this->validate($rules)) {
      return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    $ticket = $this->generateNumber('CMP', 'maintenance_requests', 'ticket_number');
    $user   = $this->currentUser();

    $this->db->table('maintenance_requests')->insert([
      'ticket_number'  => $ticket,
      'category'       => $this->request->getPost('category'),
      'description'    => $this->request->getPost('description'),
      'priority'       => $this->request->getPost('priority'),
      'status'         => 'pending',
      'facility_id'    => (int) $this->request->getPost('facility_id'),
      'unit_id'        => (int) $this->request->getPost('unit_id') ?: null,
      'requester_name' => $this->request->getPost('requester_name') ?: $user['name'],
      'requester_email'=> $this->request->getPost('requester_email') ?: $user['email'],
      'company_id'     => $user['company_id'],
      'created_at'     => date('Y-m-d H:i:s'),
    ]);

    $id = (int) $this->db->insertID();
    $this->logActivity('create', 'maintenance_requests', $id, "Complaint {$ticket}");

    return redirect()->to(base_url('complaints/view/' . $id))->with('success', 'Complaint logged.');
  }

  public function show(int $id)
  {
    $row = $this->db->table('maintenance_requests')->where('id', $id)->get()->getRowArray();
    if (! $row) {
      return redirect()->to(base_url('complaints'))->with('error', 'Not found.');
    }

    return view('complaints/show', $this->viewData([
      'title' => 'Complaint ' . ($row['ticket_number'] ?? ''),
      'row'   => $row,
    ]));
  }

  public function edit(int $id)
  {
    $row = $this->db->table('maintenance_requests')->where('id', $id)->get()->getRowArray();
    if (! $row) {
      return redirect()->to(base_url('complaints'))->with('error', 'Not found.');
    }

    return view('complaints/form', $this->viewData([
      'title' => 'Edit Complaint',
      'row'   => $row,
      'tenants' => $this->loadTenants(),
      'facilities' => $this->loadFacilities(),
    ]));
  }

  public function update(int $id)
  {
    $rules = [
      'category'    => 'required|min_length[3]',
      'description' => 'required',
      'priority'    => 'required',
      'status'      => 'required',
    ];
    if (! $this->validate($rules)) {
      return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    $this->db->table('maintenance_requests')->where('id', $id)->update([
      'category'    => $this->request->getPost('category'),
      'description' => $this->request->getPost('description'),
      'priority'    => $this->request->getPost('priority'),
      'status'      => $this->request->getPost('status'),
      'updated_at'  => date('Y-m-d H:i:s'),
    ]);

    return redirect()->to(base_url('complaints/view/' . $id))->with('success', 'Updated.');
  }

  private function loadTenants(): array
  {
    if (! $this->db->tableExists('tenants')) {
      return [];
    }

    return $this->db->table('tenants')->select('id, full_name')
      ->where('deleted_at', null)->orderBy('full_name')->get()->getResultArray();
  }

  private function loadFacilities(): array
  {
    $q = $this->db->table('facilities')->select('id, name')->where('deleted_at', null)->orderBy('name');
    $this->scopeCompany($q);

    return $q->get()->getResultArray();
  }
}
