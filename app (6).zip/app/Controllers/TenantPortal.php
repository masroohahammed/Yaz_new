<?php

namespace App\Controllers;

/**
 * Tenant / client portal workspace.
 */
class TenantPortal extends BaseController
{
  public function index()
  {
    $user = $this->currentUser();
    $tickets = [];
    $invoices = [];

    if ($this->db->tableExists('maintenance_requests')) {
      $q = $this->db->table('maintenance_requests')
        ->select('id, ticket_number, title, status, priority, created_at')
        ->orderBy('created_at', 'DESC')
        ->limit(20);
      if ($user['email']) {
        $q->where('requester_email', $user['email']);
      }
      $tickets = $q->get()->getResultArray();
    }

    if ($this->db->tableExists('invoices')) {
      $invoices = $this->db->table('invoices')
        ->select('id, invoice_number, total, status, due_date')
        ->orderBy('due_date', 'DESC')
        ->limit(20)
        ->get()->getResultArray();
    }

    return view('portal/index', $this->viewData([
      'title'    => 'Tenant Portal',
      'tickets'  => $tickets,
      'invoices' => $invoices,
    ]));
  }
}
