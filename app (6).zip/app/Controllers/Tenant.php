<?php

namespace App\Controllers;

use App\Models\Tenant_model;
use App\Services\PmCrudService;
use App\Services\PropertyAssignmentService;
use App\Services\RbacService;
use App\Services\RolePermissionService;
use App\Services\TenantPortalUserService;
use Config\PmModules;

/**
 * Tenants — dedicated module with 360° profile (leases, payments, complaints).
 */
class Tenant extends BaseController
{
    private Tenant_model $tenantModel;
    private PmCrudService $crud;

    public function initController(\CodeIgniter\HTTP\RequestInterface $request,
                                   \CodeIgniter\HTTP\ResponseInterface $response,
                                   \Psr\Log\LoggerInterface $logger): void
    {
        parent::initController($request, $response, $logger);
        $this->tenantModel = new Tenant_model();
        $this->crud        = new PmCrudService($this->db);
    }

    public function index()
    {
        $this->assertPerm();
        $filters = $this->request->getGet() ?? [];
        $page    = max(1, (int) ($filters['page'] ?? 1));
        $facilityIds = $this->scopedFacilityIds();

        $result = $this->tenantModel->listPaginated($filters, 20, $page, $facilityIds);

        return view('tenants/index', $this->viewData([
            'title'   => 'Tenants',
            'tenants' => $result['rows'],
            'total'   => $result['total'],
            'perPage' => $result['perPage'],
            'page'    => $result['page'],
            'filters' => $filters,
        ]));
    }

    public function view(int $id)
    {
        $this->assertPerm();
        $tenant = $this->tenantModel->findDetail($id);
        if (! $tenant) {
            return redirect()->to(base_url('tenants'))->with('error', 'Tenant not found.');
        }

        return view('tenants/view', $this->viewData([
            'title'    => $tenant['full_name'],
            'tenant'   => $tenant,
            'data360'  => $this->tenantModel->get360Data($id),
        ]));
    }

    public function create()
    {
        $this->assertPerm();

        return $this->formView([]);
    }

    public function store()
    {
        $this->assertPerm();
        $post = $this->request->getPost();
        $check = $this->tenantModel->validateTenantData($post, false);
        if ($check['errors']) {
            return redirect()->back()->withInput()->with('errors', $check['errors']);
        }

        $user   = $this->currentUser();
        $result = $this->crud->validateAndBuild('tenants', $post, $user, false);
        if ($result['errors']) {
            return redirect()->back()->withInput()->with('errors', $result['errors']);
        }

        $data = $result['data'];
        $data['tenant_type'] = $this->tenantModel->normalizeTenantType($post['tenant_type'] ?? 'Personal');

        $this->tenantModel->insert($data);
        $id = (int) $this->tenantModel->getInsertID();
        $newUnit = (int) ($data['current_unit_id'] ?? 0) ?: null;
        if ($newUnit) {
            $this->tenantModel->syncCurrentUnit($id, null, $newUnit);
        }
        (new TenantPortalUserService($this->db))->linkOrCreateForTenant($id);
        $this->logActivity('create', 'tenants', $id, 'Tenant created');

        $redirect = redirect()->to(base_url('tenants/view/' . $id))->with('success', 'Tenant created.');
        if ($check['warnings']) {
            $redirect->with('warning', implode(' ', $check['warnings']));
        }

        return $redirect;
    }

    public function edit(int $id)
    {
        $this->assertPerm();
        $tenant = $this->crud->row('tenants', $id);
        if (! $tenant) {
            return redirect()->to(base_url('tenants'))->with('error', 'Tenant not found.');
        }

        return $this->formView($tenant);
    }

    public function update(int $id)
    {
        $this->assertPerm();
        $tenant = $this->crud->row('tenants', $id);
        if (! $tenant) {
            return redirect()->to(base_url('tenants'))->with('error', 'Tenant not found.');
        }

        $post  = $this->request->getPost();
        $check = $this->tenantModel->validateTenantData($post, true, $id);
        if ($check['errors']) {
            return redirect()->back()->withInput()->with('errors', $check['errors']);
        }

        $user   = $this->currentUser();
        $result = $this->crud->validateAndBuild('tenants', $post, $user, true);
        if ($result['errors']) {
            return redirect()->back()->withInput()->with('errors', $result['errors']);
        }

        $data = $result['data'];
        $data['tenant_type'] = $this->tenantModel->normalizeTenantType($post['tenant_type'] ?? $tenant['tenant_type']);

        $oldUnit = (int) ($tenant['current_unit_id'] ?? 0) ?: null;
        $newUnit = (int) ($data['current_unit_id'] ?? 0) ?: null;

        $this->tenantModel->update($id, $data);
        $this->tenantModel->syncCurrentUnit($id, $oldUnit, $newUnit);
        (new TenantPortalUserService($this->db))->linkOrCreateForTenant($id);
        $this->logActivity('update', 'tenants', $id, 'Tenant updated');

        $redirect = redirect()->to(base_url('tenants/view/' . $id))->with('success', 'Tenant updated.');
        if ($check['warnings']) {
            $redirect->with('warning', implode(' ', $check['warnings']));
        }

        return $redirect;
    }

    public function delete(int $id)
    {
        $this->assertPerm();
        $this->requireRole('super_admin', 'property_manager', 'facility_manager');

        $this->tenantModel->delete($id);
        $this->logActivity('delete', 'tenants', $id, 'Tenant removed');

        return redirect()->to(base_url('tenants'))->with('success', 'Tenant removed.');
    }

    public function exportCsv()
    {
        $this->assertPerm();

        $result = $this->tenantModel->listPaginated([], 100000, 1, $this->scopedFacilityIds());
        $rows   = $result['rows'];

        $filename = 'tenants_' . date('Ymd_His') . '.csv';
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $fp = fopen('php://output', 'w');
        fputcsv($fp, ['ID', 'Type', 'Full Name', 'Phone', 'WhatsApp', 'Email', 'Nationality', 'QID No', 'Passport No', 'Company Name', 'Status', 'Created At']);
        foreach ($rows as $r) {
            fputcsv($fp, [
                $r['id'],
                $r['tenant_type'],
                $r['full_name'],
                $r['phone'] ?? '',
                $r['whatsapp'] ?? '',
                $r['email'] ?? '',
                $r['nationality'] ?? '',
                $r['qid_no'] ?? '',
                $r['passport_no'] ?? '',
                $r['company_name'] ?? '',
                $r['status'],
                $r['created_at'] ?? '',
            ]);
        }
        fclose($fp);
        exit;
    }

    public function blacklist(int $id)
    {
        return $this->action($id, 'blacklist');
    }

    public function action(int $id, string $action)
    {
        $this->assertPerm();
        $tenant = $this->crud->row('tenants', $id);
        if (! $tenant) {
            return redirect()->to(base_url('tenants'))->with('error', 'Tenant not found.');
        }

        if ($action === 'blacklist') {
            $updates = [
                'status'     => 'blacklisted',
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            if ($this->db->fieldExists('is_blacklisted', 'tenants')) {
                $updates['is_blacklisted'] = 1;
            }
            $this->tenantModel->update($id, $updates);
            $this->logActivity('update', 'tenants', $id, 'Tenant blacklisted');

            return redirect()->to(base_url('tenants/view/' . $id))->with('success', 'Tenant blacklisted.');
        }

        if ($action === 'unblacklist') {
            $updates = [
                'status'     => 'active',
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            if ($this->db->fieldExists('is_blacklisted', 'tenants')) {
                $updates['is_blacklisted'] = 0;
            }
            $this->tenantModel->update($id, $updates);
            $this->logActivity('update', 'tenants', $id, 'Tenant removed from blacklist');

            return redirect()->to(base_url('tenants/view/' . $id))->with('success', 'Blacklist removed.');
        }

        return redirect()->back()->with('error', 'Unknown action.');
    }

    private function formView(array $row)
    {
        $units = [];
        if ($this->db->tableExists('units')) {
            $units = $this->db->table('units u')
                ->select('u.id, u.unit_number, f.name AS property_name')
                ->join('facilities f', 'f.id = u.facility_id', 'left')
                ->where('u.deleted_at', null)
                ->orderBy('f.name')
                ->orderBy('u.unit_number')
                ->get()->getResultArray();
        }

        return view('tenants/form', $this->viewData([
            'title'  => 'Tenants',
            'tenant' => $row,
            'units'  => $units,
            'isEdit' => ! empty($row['id']),
        ]));
    }

    private function assertPerm(): void
    {
        $module = PmModules::get('tenants');
        $role   = session()->get('user_role') ?? 'client';
        $rbac   = new RbacService($this->db);
        if (! $rbac->can($role, $module['permission'])) {
            redirect()->to(base_url('dashboard'))
                ->with('error', 'You do not have permission to access tenants.')
                ->send();
            exit;
        }

        $roleId = (int) (session()->get('role_id') ?? 0);
        if ($roleId > 0 && $role !== 'super_admin') {
            $permSvc = new RolePermissionService($this->db);
            if (! $permSvc->can($roleId, 'tenants', 'view')) {
                redirect()->to(base_url('dashboard'))
                    ->with('error', 'Module access denied.')
                    ->send();
                exit;
            }
        }
    }

    /** @return list<int>|null null = no facility scoping */
    private function scopedFacilityIds(): ?array
    {
        $user = $this->currentUser();
        $role = session()->get('user_role') ?? '';

        return (new PropertyAssignmentService($this->db))->assignedFacilityIds((int) $user['id'], $role);
    }
}
