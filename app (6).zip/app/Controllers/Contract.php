<?php

namespace App\Controllers;

use App\Models\Contract_model;
use App\Models\Property_model;
use App\Services\LeaseInvoiceService;
use App\Services\PropertyAssignmentService;
use App\Services\RbacService;
use App\Services\RolePermissionService;
use App\Services\UnitByPropertyService;
use App\Services\UtilityAccountService;
use Config\PmModules;

/**
 * Lease contracts — MODULE 06 (lease_contracts table).
 */
class Contract extends BaseController
{
    private Contract_model $contractModel;

    public function initController(\CodeIgniter\HTTP\RequestInterface $request,
                                   \CodeIgniter\HTTP\ResponseInterface $response,
                                   \Psr\Log\LoggerInterface $logger): void
    {
        parent::initController($request, $response, $logger);
        $this->contractModel = new Contract_model();
    }

    public function index()
    {
        $this->assertPerm();
        $filters = $this->request->getGet() ?? [];
        $page    = max(1, (int) ($filters['page'] ?? 1));
        $result  = $this->contractModel->listPaginated($filters, 20, $page, $this->scopedFacilityIds());

        $properties = $this->db->table('facilities')
            ->select('id, name')
            ->where('deleted_at', null)
            ->orderBy('name')
            ->get()->getResultArray();

        return view('contracts/index', $this->viewData([
            'title'      => 'Lease Contracts',
            'contracts'  => $result['rows'],
            'total'      => $result['total'],
            'perPage'    => $result['perPage'],
            'page'       => $result['page'],
            'filters'    => $filters,
            'properties' => $properties,
        ]));
    }

    public function view(int $id)
    {
        $this->assertPerm();
        $contract = $this->contractModel->findDetail($id);
        if (! $contract) {
            return redirect()->to($this->listUrl())->with('error', 'Contract not found.');
        }

        return view('contracts/view', $this->viewData([
            'title'    => $contract['contract_number'] ?? 'Contract #' . $id,
            'contract' => $contract,
            'data360'  => $this->contractModel->get360Data($id),
        ]));
    }

    public function create()
    {
        $this->assertPerm();

        return view('contracts/form', $this->viewData([
            'title'      => 'New Contract',
            'contract'   => [],
            'tenants'    => $this->tenantOptions(),
            'properties' => $this->propertyOptions(),
            'templates'  => $this->templateOptions(),
            'rentSchedule' => [],
        ]));
    }

    public function store()
    {
        $this->assertPerm();
        $user   = $this->currentUser();
        $result = $this->contractModel->validateAndBuild($this->request->getPost(), $user, false);

        if ($result['errors']) {
            return redirect()->back()->withInput()->with('errors', $result['errors']);
        }

        $data = $result['data'];
        $data['contract_number'] = $this->generateNumber('LC', 'lease_contracts', 'contract_number');

        $this->contractModel->insert($data);
        $id = (int) $this->contractModel->getInsertID();

        $this->contractModel->syncRentSchedule($id, (array) $this->request->getPost('annual_rent'));
        $this->postSaveBilling($id, true);
        $this->contractModel->activateUnitAndTenant($id);

        if (($data['status'] ?? '') === 'active') {
            (new UtilityAccountService($this->db))->transferToTenantForUnit(
                (int) $data['unit_id'],
                (int) $data['tenant_id'],
                $data['start_date'] ?? date('Y-m-d')
            );
        }

        $this->logActivity('create', 'lease_contracts', $id, 'Contract created');

        $warn = $this->blacklistWarning((int) $data['tenant_id']);

        return redirect()->to($this->viewUrl($id))
            ->with('success', 'Contract saved and invoice schedule generated.')
            ->with('warning', $warn);
    }

    public function edit(int $id)
    {
        $this->assertPerm();
        $contract = $this->contractModel->findDetail($id);
        if (! $contract) {
            return redirect()->to($this->listUrl())->with('error', 'Contract not found.');
        }

        $rentSchedule = [];
        if ($this->db->tableExists('contract_rent_schedule')) {
            $rentSchedule = $this->db->table('contract_rent_schedule')
                ->where('contract_id', $id)
                ->orderBy('year_number')
                ->get()->getResultArray();
        }

        return view('contracts/form', $this->viewData([
            'title'        => 'Edit Contract',
            'contract'     => $contract,
            'tenants'      => $this->tenantOptions(),
            'properties'   => $this->propertyOptions(),
            'templates'    => $this->templateOptions(),
            'rentSchedule' => $rentSchedule,
        ]));
    }

    public function update(int $id)
    {
        $this->assertPerm();
        $existing = $this->contractModel->find($id);
        if (! $existing) {
            return redirect()->to($this->listUrl())->with('error', 'Contract not found.');
        }

        $user   = $this->currentUser();
        $result = $this->contractModel->validateAndBuild($this->request->getPost(), $user, true, $id);

        if ($result['errors']) {
            return redirect()->back()->withInput()->with('errors', $result['errors']);
        }

        $data = $result['data'];
        $data['edited_at'] = date('Y-m-d H:i:s');
        $data['edited_by'] = (int) $user['id'];

        $this->contractModel->update($id, $data);
        $this->contractModel->syncRentSchedule($id, (array) $this->request->getPost('annual_rent'));

        $this->logActivity('update', 'lease_contracts', $id, 'Contract updated (forward-only — issued invoices unchanged)');

        return redirect()->to($this->viewUrl($id))->with('success', 'Contract updated.');
    }

    public function delete(int $id)
    {
        $this->assertPerm();
        $this->requireRole('super_admin', 'property_manager', 'finance_manager');
        $this->contractModel->delete($id);
        $this->logActivity('delete', 'lease_contracts', $id, 'Contract deleted');

        return redirect()->to($this->listUrl())->with('success', 'Contract removed.');
    }

    public function print_contract(int $id)
    {
        return $this->printContract($id);
    }

    public function printContract(int $id)
    {
        $this->assertPerm();
        $c = $this->contractModel->findDetail($id);
        if (! $c) {
            return redirect()->to($this->listUrl())->with('error', 'Contract not found.');
        }

        $template = null;
        if (! empty($c['template_id']) && $this->db->tableExists('contract_templates')) {
            $template = $this->db->table('contract_templates')->where('id', $c['template_id'])->get()->getRowArray();
        }

        $body   = $c['custom_content_en'] ?: ($template['content_en'] ?? '');
        $bodyAr = $c['custom_content_ar'] ?: ($template['content_ar'] ?? '');
        $map    = [
            'tenant_name'     => $c['tenant_name'] ?? '',
            'rent_amount'     => $c['rent_amount'] ?? '',
            'start_date'      => $c['start_date'] ?? '',
            'end_date'        => $c['end_date'] ?? '',
            'unit'            => $c['unit_number'] ?? '',
            'unit_number'     => $c['unit_number'] ?? '',
            'property'        => $c['property_name'] ?? '',
            'property_name'   => $c['property_name'] ?? '',
            'facility_name'   => $c['property_name'] ?? '',
            'contract_number' => $c['contract_number'] ?? '',
            'payment_frequency' => $c['payment_frequency'] ?? '',
            'currency'        => $this->settings['currency'] ?? 'QAR',
        ];
        $body   = $this->mergeTemplate($body, $map);
        $bodyAr = $this->mergeTemplate($bodyAr, $map);

        $data = $this->viewData([
            'title'    => 'Contract ' . ($c['contract_number'] ?? $id),
            'contract' => $c,
            'body'     => $body,
            'bodyAr'   => $bodyAr,
        ]);

        if ($this->request->getGet('pdf') && class_exists(\Dompdf\Dompdf::class)) {
            $dompdf = new \Dompdf\Dompdf();
            $dompdf->loadHtml(view('pm/contract_print', $data));
            $dompdf->setPaper('A4');
            $dompdf->render();

            return $this->response
                ->setHeader('Content-Type', 'application/pdf')
                ->setBody($dompdf->output());
        }

        return view('pm/contract_print', $data);
    }

    public function save_print(int $id)
    {
        $this->assertPerm();
        $this->contractModel->update($id, [
            'custom_content_en' => $this->request->getPost('custom_content_en'),
            'custom_content_ar' => $this->request->getPost('custom_content_ar'),
            'edited_at'         => date('Y-m-d H:i:s'),
            'edited_by'         => (int) $this->currentUser()['id'],
            'updated_at'        => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to($this->printUrl($id))->with('success', 'Print content saved.');
    }

    public function get_units_by_property(int $propertyId)
    {
        $svc = new UnitByPropertyService($this->db);

        return $this->response->setJSON(['ok' => true, 'units' => $svc->json($propertyId)]);
    }

    public function amendment(int $id)
    {
        $this->assertPerm();
        $contract = $this->contractModel->findDetail($id);
        if (! $contract) {
            return redirect()->to($this->listUrl())->with('error', 'Contract not found.');
        }

        if ($this->request->getMethod() === 'post') {
            if ($this->db->tableExists('lease_amendments')) {
                $this->db->table('lease_amendments')->insert([
                    'contract_id'        => $id,
                    'new_rent'           => $this->request->getPost('new_rent'),
                    'new_end_date'       => $this->request->getPost('new_end_date'),
                    'effective_date'     => $this->request->getPost('effective_date'),
                    'description'        => $this->request->getPost('description'),
                    'created_by'         => $this->currentUser()['id'],
                    'created_at'         => date('Y-m-d H:i:s'),
                ]);
            }

            $updates = [
                'edited_at' => date('Y-m-d H:i:s'),
                'edited_by' => (int) $this->currentUser()['id'],
                'updated_at'=> date('Y-m-d H:i:s'),
            ];
            if ($this->request->getPost('custom_content_en')) {
                $updates['custom_content_en'] = $this->request->getPost('custom_content_en');
            }
            if ($this->request->getPost('custom_content_ar')) {
                $updates['custom_content_ar'] = $this->request->getPost('custom_content_ar');
            }
            if ($this->request->getPost('new_rent')) {
                $updates['rent_amount'] = $this->request->getPost('new_rent');
            }
            if ($this->request->getPost('new_end_date')) {
                $updates['end_date'] = $this->request->getPost('new_end_date');
            }
            $this->contractModel->update($id, $updates);

            $annualRent = (array) $this->request->getPost('annual_rent');
            if ($annualRent) {
                $this->contractModel->syncRentSchedule($id, $annualRent);
            }

            if ($this->request->getPost('refresh_payment_schedule')) {
                $svc = new LeaseInvoiceService($this->db);
                $n   = $svc->regenerateSchedule($id, fn ($p, $t, $c) => $this->generateNumber($p, $t, $c));

                return redirect()->to($this->viewUrl($id))
                    ->with('success', "Amendment saved. Regenerated {$n} pending payment(s).");
            }

            return redirect()->to($this->viewUrl($id))->with('success', 'Amendment saved.');
        }

        $rentSchedule = [];
        if ($this->db->tableExists('contract_rent_schedule')) {
            $rentSchedule = $this->db->table('contract_rent_schedule')
                ->where('contract_id', $id)->orderBy('year_number')->get()->getResultArray();
        }

        return view('contracts/amendment', $this->viewData([
            'title'        => 'Contract Amendment',
            'contract'     => $contract,
            'rentSchedule' => $rentSchedule,
        ]));
    }

    public function renew(int $id)
    {
        $this->assertPerm();
        $c = $this->contractModel->find($id);
        if (! $c) {
            return redirect()->to($this->listUrl())->with('error', 'Contract not found.');
        }

        if ($this->request->getMethod() === 'post') {
            $newStart = $this->request->getPost('new_start_date');
            $newEnd   = $this->request->getPost('new_end_date');
            $newRent  = $this->request->getPost('new_rent') ?: $c['rent_amount'];

            if ($newEnd <= $newStart) {
                return redirect()->back()->withInput()->with('error', 'End date must be after start date.');
            }

            $num = $this->generateNumber('LC', 'lease_contracts', 'contract_number');
            $this->contractModel->insert([
                'company_id'             => $c['company_id'],
                'contract_number'        => $num,
                'tenant_id'              => $c['tenant_id'],
                'facility_id'            => $c['facility_id'],
                'unit_id'                => $c['unit_id'],
                'template_id'            => $c['template_id'],
                'status'                 => 'active',
                'start_date'             => $newStart,
                'end_date'               => $newEnd,
                'rent_amount'            => $newRent,
                'payment_frequency'      => $c['payment_frequency'],
                'payment_type'         => $c['payment_type'],
                'parent_contract_id'     => $id,
                'auto_generate_invoices' => 1,
                'created_by'             => $this->currentUser()['id'],
                'created_at'             => date('Y-m-d H:i:s'),
            ]);
            $newId = (int) $this->contractModel->getInsertID();
            $this->contractModel->update($id, ['status' => 'renewed', 'updated_at' => date('Y-m-d H:i:s')]);

            $this->postSaveBilling($newId, true);
            $this->contractModel->activateUnitAndTenant($newId);

            return redirect()->to($this->viewUrl($newId))->with('success', 'Renewal contract created.');
        }

        return view('contracts/renew', $this->viewData([
            'title'    => 'Renew Contract',
            'contract' => $c,
        ]));
    }

    public function apply_penalties(int $id)
    {
        return $this->applyPenalties($id);
    }

    public function applyPenalties(int $id)
    {
        $this->assertPerm();
        $c = $this->contractModel->find($id);
        if (! $c) {
            return redirect()->back()->with('error', 'Contract not found.');
        }

        $pct   = (float) ($c['late_penalty_pct'] ?? 0);
        $grace = (int) ($c['grace_period_days'] ?? 0);
        $count = 0;

        if ($pct > 0 && $this->db->tableExists('lease_payments')) {
            $overdue = $this->db->table('lease_payments')
                ->where('contract_id', $id)
                ->whereIn('status', ['pending', 'overdue'])
                ->where('due_date <', date('Y-m-d', strtotime("-{$grace} days")))
                ->get()->getResultArray();

            foreach ($overdue as $p) {
                $penalty = round((float) $p['amount'] * $pct / 100, 2);
                $this->db->table('lease_payments')->insert([
                    'company_id'     => $c['company_id'],
                    'payment_number' => $this->generateNumber('PAY', 'lease_payments', 'payment_number'),
                    'contract_id'    => $id,
                    'tenant_id'      => $c['tenant_id'],
                    'facility_id'    => $c['facility_id'],
                    'unit_id'        => $c['unit_id'],
                    'payment_type'   => 'penalty',
                    'payment_method' => 'other',
                    'amount'         => $penalty,
                    'status'         => 'pending',
                    'due_date'       => date('Y-m-d'),
                    'notes'          => 'Late penalty for ' . ($p['payment_number'] ?? $p['id']),
                    'created_by'     => $this->currentUser()['id'],
                    'created_at'     => date('Y-m-d H:i:s'),
                ]);
                $count++;
            }
        }

        return redirect()->to($this->viewUrl($id))->with('success', "Applied {$count} penalty invoice(s).");
    }

    public function regenerate_invoices(int $id)
    {
        return $this->regenerateInvoices($id);
    }

    public function regenerateInvoices(int $id)
    {
        $this->assertPerm();
        $svc = new LeaseInvoiceService($this->db);
        $n   = $svc->regenerateSchedule($id, fn ($p, $t, $c) => $this->generateNumber($p, $t, $c));

        return redirect()->to($this->viewUrl($id))
            ->with('success', "Regenerated {$n} payment schedule row(s).");
    }

    public function terminate(int $id)
    {
        $this->assertPerm();
        $c = $this->contractModel->find($id);
        if (! $c) {
            return redirect()->to($this->listUrl())->with('error', 'Contract not found.');
        }

        if ($this->request->getMethod() === 'post') {
            $terminationDate = $this->request->getPost('termination_date');
            $reason          = trim((string) $this->request->getPost('reason') ?: $this->request->getPost('termination_reason'));

            if (! $terminationDate) {
                return redirect()->back()->with('error', 'Termination date is required.');
            }
            if ($reason === '') {
                return redirect()->back()->with('error', 'Termination reason is required.');
            }
            if ($terminationDate < $c['start_date']) {
                return redirect()->back()->with('error', 'Termination date cannot be before contract start.');
            }

            $this->contractModel->update($id, [
                'status'             => 'terminated',
                'end_date'           => $terminationDate,
                'termination_reason' => $reason,
                'updated_at'         => date('Y-m-d H:i:s'),
            ]);

            $this->contractModel->releaseUnitAndTenant($c);

            (new UtilityAccountService($this->db))->transferBackForUnit(
                (int) $c['unit_id'],
                $terminationDate,
                $reason
            );

            if (! empty($this->request->getPost('refund_deposit')) && $this->db->tableExists('lease_payments')) {
                $deposit = (float) ($c['security_deposit'] ?? 0);
                if ($deposit > 0) {
                    $this->db->table('lease_payments')->insert([
                        'company_id'     => $c['company_id'],
                        'payment_number' => $this->generateNumber('PAY', 'lease_payments', 'payment_number'),
                        'contract_id'    => $id,
                        'tenant_id'      => $c['tenant_id'],
                        'facility_id'    => $c['facility_id'],
                        'unit_id'        => $c['unit_id'],
                        'payment_type'   => 'deposit_refund',
                        'payment_method' => 'transfer',
                        'amount'         => -$deposit,
                        'status'         => 'pending',
                        'due_date'       => date('Y-m-d'),
                        'notes'          => 'Security deposit refund on termination',
                        'created_by'     => $this->currentUser()['id'],
                        'created_at'     => date('Y-m-d H:i:s'),
                    ]);
                }
            }

            $this->logActivity('update', 'lease_contracts', $id, 'Contract terminated');

            return redirect()->to($this->viewUrl($id))->with('success', 'Contract terminated.');
        }

        return view('contracts/terminate', $this->viewData([
            'title'    => 'Terminate Contract',
            'contract' => $c,
        ]));
    }

    public function exportCsv()
    {
        $this->assertPerm();

        $q = $this->db->table('lease_contracts lc')
            ->select('lc.contract_number, t.full_name AS tenant_name, f.name AS facility_name, u.unit_number, lc.status, lc.start_date, lc.end_date, lc.rent_amount, lc.payment_frequency')
            ->join('tenants t', 't.id = lc.tenant_id', 'left')
            ->join('facilities f', 'f.id = lc.facility_id', 'left')
            ->join('units u', 'u.id = lc.unit_id', 'left')
            ->where('lc.deleted_at', null);

        $facilityIds = $this->scopedFacilityIds();
        if ($facilityIds !== null) {
            if (empty($facilityIds)) {
                $q->where('1 = 0', null, false);
            } else {
                $q->whereIn('lc.facility_id', $facilityIds);
            }
        }

        $rows = $q->orderBy('lc.id', 'DESC')->get()->getResultArray();

        return $this->csvResponse(
            'contracts_' . date('Ymd') . '.csv',
            ['Contract #', 'Tenant', 'Property', 'Unit', 'Status', 'Start', 'End', 'Rent', 'Frequency'],
            $rows
        );
    }

    private function postSaveBilling(int $contractId, bool $generate): void
    {
        if (! $generate) {
            return;
        }
        $svc = new LeaseInvoiceService($this->db);
        $svc->generateSchedule($contractId, fn ($p, $t, $c) => $this->generateNumber($p, $t, $c));
    }

    private function mergeTemplate(string $text, array $map): string
    {
        foreach ($map as $key => $value) {
            $text = str_replace('{{' . $key . '}}', (string) $value, $text);
            $text = str_replace('{' . $key . '}', (string) $value, $text);
        }

        return $text;
    }

    private function tenantOptions(): array
    {
        if (! $this->db->tableExists('tenants')) {
            return [];
        }

        $rows = $this->db->table('tenants')
            ->select($this->tenantOptionSelect())
            ->where('deleted_at', null)
            ->orderBy('full_name')
            ->get()->getResultArray();

        foreach ($rows as &$row) {
            if (! array_key_exists('is_blacklisted', $row)) {
                $row['is_blacklisted'] = (($row['status'] ?? '') === 'blacklisted') ? 1 : 0;
            }
        }
        unset($row);

        return $rows;
    }

    private function tenantOptionSelect(): string
    {
        $cols = ['id', 'full_name'];
        if ($this->db->fieldExists('is_blacklisted', 'tenants')) {
            $cols[] = 'is_blacklisted';
        } else {
            $cols[] = 'status';
        }

        return implode(', ', $cols);
    }

    private function propertyOptions(): array
    {
        return $this->db->table('facilities')
            ->select('id, name')
            ->where('deleted_at', null)
            ->orderBy('name')
            ->get()->getResultArray();
    }

    private function templateOptions(): array
    {
        if (! $this->db->tableExists('contract_templates')) {
            return [];
        }

        $q = $this->db->table('contract_templates')->select('id, name');

        if ($this->db->fieldExists('is_active', 'contract_templates')) {
            $q->where('is_active', 1);
        } elseif ($this->db->fieldExists('status', 'contract_templates')) {
            $q->where('status', 'active');
        }

        return $q->orderBy('name')->get()->getResultArray();
    }

    private function blacklistWarning(int $tenantId): ?string
    {
        if ($tenantId <= 0) {
            return null;
        }
        $t = $this->db->table('tenants')->where('id', $tenantId)->get()->getRowArray();
        if ($t) {
            $blacklisted = ! empty($t['is_blacklisted']) || (($t['status'] ?? '') === 'blacklisted');
            if ($blacklisted) {
                return 'Warning: this tenant is blacklisted.';
            }
        }

        return null;
    }

    private function assertPerm(): void
    {
        $module = PmModules::get('leases');
        $role   = session()->get('user_role') ?? 'client';
        $rbac   = new RbacService($this->db);
        if (! $rbac->can($role, $module['permission'])) {
            redirect()->to(base_url('dashboard'))->with('error', 'Access denied.')->send();
            exit;
        }

        $roleId = (int) (session()->get('role_id') ?? 0);
        if ($roleId > 0 && $role !== 'super_admin') {
            $permSvc = new RolePermissionService($this->db);
            if (! $permSvc->can($roleId, 'leases', 'view')) {
                redirect()->to(base_url('dashboard'))->with('error', 'Access denied.')->send();
                exit;
            }
        }
    }

    private function scopedFacilityIds(): ?array
    {
        $user = $this->currentUser();
        $role = session()->get('user_role') ?? '';

        return (new PropertyAssignmentService($this->db))->assignedFacilityIds((int) $user['id'], $role);
    }

    private function listUrl(): string
    {
        return base_url('contracts');
    }

    private function viewUrl(int $id): string
    {
        return base_url('contracts/view/' . $id);
    }

    private function printUrl(int $id): string
    {
        return base_url('contracts/print/' . $id);
    }

    /**
     * @param list<string>                $headers
     * @param list<array<string, mixed>>  $rows
     */
    private function csvResponse(string $filename, array $headers, array $rows): \CodeIgniter\HTTP\Response
    {
        $output = implode(',', array_map(fn ($h) => '"' . $h . '"', $headers)) . "\n";
        foreach ($rows as $row) {
            $output .= implode(',', array_map(
                fn ($v) => '"' . str_replace('"', '""', (string) $v) . '"',
                array_values($row)
            )) . "\n";
        }

        return $this->response
            ->setHeader('Content-Type', 'text/csv')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
            ->setBody($output);
    }
}
