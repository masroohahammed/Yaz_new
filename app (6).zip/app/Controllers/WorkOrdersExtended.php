<?php

namespace App\Controllers;

/**
 * @deprecated Merged into WorkOrders.php — kept for deployments that still require this file.
 */
trait WorkOrdersLegacyTrait
{
}
