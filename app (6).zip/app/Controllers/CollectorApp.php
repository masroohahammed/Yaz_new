<?php

namespace App\Controllers;

/**
 * Cash collector field workspace — sessions and assignments.
 */
class CollectorApp extends BaseController
{
  public function index()
  {
    $sessions = [];
    $assignments = [];

    if ($this->db->tableExists('collector_sessions')) {
      $sessions = $this->db->table('collector_sessions')
        ->orderBy('started_at', 'DESC')
        ->limit(50)
        ->get()->getResultArray();
    }

    if ($this->db->tableExists('collection_assignments')) {
      $assignments = $this->db->table('collection_assignments')
        ->orderBy('assigned_date', 'DESC')
        ->limit(50)
        ->get()->getResultArray();
    }

    return view('collector/index', $this->viewData([
      'title'       => 'Cash Collector',
      'sessions'    => $sessions,
      'assignments' => $assignments,
    ]));
  }

  public function startSession()
  {
    $user = $this->currentUser();
    if (! $this->db->tableExists('collector_sessions')) {
      return redirect()->back()->with('error', 'Collector module not installed.');
    }

    $code = $this->generateNumber('CS', 'collector_sessions', 'session_code');
    $this->db->table('collector_sessions')->insert([
      'company_id'     => $user['company_id'],
      'collector_id'   => $user['id'],
      'session_code'   => $code,
      'started_at'     => date('Y-m-d H:i:s'),
      'status'         => 'open',
      'opening_float'  => (float) $this->request->getPost('opening_float'),
      'notes'          => $this->request->getPost('notes'),
      'created_at'     => date('Y-m-d H:i:s'),
    ]);

    return redirect()->to(base_url('collector'))->with('success', "Session {$code} started.");
  }

  public function closeSession(int $id)
  {
    if (! $this->db->tableExists('collector_sessions')) {
      return redirect()->back()->with('error', 'Collector module not installed.');
    }

    $this->db->table('collector_sessions')->where('id', $id)->update([
      'status'       => 'closed',
      'closed_at'    => date('Y-m-d H:i:s'),
      'closing_cash' => (float) $this->request->getPost('closing_cash'),
      'notes'        => $this->request->getPost('notes'),
    ]);

    return redirect()->to(base_url('collector'))->with('success', 'Session closed.');
  }

  public function storeAssignment()
  {
    $user = $this->currentUser();
    if (! $this->db->tableExists('collection_assignments')) {
      return redirect()->back()->with('error', 'Assignments table not installed.');
    }

    $this->db->table('collection_assignments')->insert([
      'company_id'    => $user['company_id'],
      'collector_id'  => $user['id'],
      'tenant_id'     => (int) $this->request->getPost('tenant_id') ?: null,
      'facility_id'   => (int) $this->request->getPost('facility_id') ?: null,
      'payment_id'    => (int) $this->request->getPost('payment_id') ?: null,
      'assigned_date' => $this->request->getPost('assigned_date') ?: date('Y-m-d'),
      'status'        => 'pending',
      'notes'         => $this->request->getPost('notes'),
      'created_by'    => $user['id'],
      'created_at'    => date('Y-m-d H:i:s'),
    ]);

    return redirect()->to(base_url('collector'))->with('success', 'Assignment created.');
  }

  public function markCollected(int $id)
  {
    if ($this->db->tableExists('collection_assignments')) {
      $this->db->table('collection_assignments')->where('id', $id)->update(['status' => 'collected']);
    }

    return redirect()->to(base_url('collector'))->with('success', 'Marked collected.');
  }
}
