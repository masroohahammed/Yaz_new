<?php

namespace App\Controllers;

use App\Models\Landlord_model;
use App\Services\LandlordPayoutService;
use App\Services\PmCrudService;
use App\Services\PropertyAssignmentService;
use App\Services\RbacService;
use App\Services\RolePermissionService;
use Config\PmModules;

/**
 * Landlords — dedicated module with documents, payouts, and reminders.
 */
class Landlord extends BaseController
{
    private Landlord_model $landlordModel;
    private PmCrudService $crud;

    public function initController(\CodeIgniter\HTTP\RequestInterface $request,
                                   \CodeIgniter\HTTP\ResponseInterface $response,
                                   \Psr\Log\LoggerInterface $logger): void
    {
        parent::initController($request, $response, $logger);
        $this->landlordModel = new Landlord_model();
        $this->crud          = new PmCrudService($this->db);
    }

    public function index()
    {
        $this->assertPerm();
        $filters     = $this->request->getGet() ?? [];
        $page        = max(1, (int) ($filters['page'] ?? 1));
        $facilityIds = $this->scopedFacilityIds();

        $result = $this->landlordModel->listPaginated($filters, 20, $page, $facilityIds);

        return view('landlords/index', $this->viewData([
            'title'     => 'Landlords',
            'landlords' => $result['rows'],
            'total'     => $result['total'],
            'perPage'   => $result['perPage'],
            'page'      => $result['page'],
            'filters'   => $filters,
        ]));
    }

    public function view(int $id)
    {
        $this->assertPerm();
        $landlord = $this->landlordModel->findDetail($id);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        return view('landlords/view', $this->viewData([
            'title'    => $landlord['full_name'],
            'landlord' => $landlord,
            'data360'  => $this->landlordModel->get360Data($id),
        ]));
    }

    public function create()
    {
        $this->assertPerm();

        return $this->formView([]);
    }

    public function store()
    {
        $this->assertPerm();
        $post  = $this->request->getPost();
        $check = $this->landlordModel->validateLandlordData($post, false);
        if ($check['errors']) {
            return redirect()->back()->withInput()->with('errors', $check['errors']);
        }

        $user   = $this->currentUser();
        $result = $this->crud->validateAndBuild('landlords', $post, $user, false);
        if ($result['errors']) {
            return redirect()->back()->withInput()->with('errors', $result['errors']);
        }

        $this->landlordModel->insert($result['data']);
        $id = (int) $this->landlordModel->getInsertID();
        $this->logActivity('create', 'landlords', $id, 'Landlord created');

        $redirect = redirect()->to(base_url('landlords/view/' . $id))->with('success', 'Landlord created.');
        if ($check['warnings']) {
            $redirect->with('warning', implode(' ', $check['warnings']));
        }

        return $redirect;
    }

    public function edit(int $id)
    {
        $this->assertPerm();
        $landlord = $this->crud->row('landlords', $id);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        return $this->formView($landlord);
    }

    public function update(int $id)
    {
        $this->assertPerm();
        $landlord = $this->crud->row('landlords', $id);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        $post  = $this->request->getPost();
        $check = $this->landlordModel->validateLandlordData($post, true);
        if ($check['errors']) {
            return redirect()->back()->withInput()->with('errors', $check['errors']);
        }

        $user   = $this->currentUser();
        $result = $this->crud->validateAndBuild('landlords', $post, $user, true);
        if ($result['errors']) {
            return redirect()->back()->withInput()->with('errors', $result['errors']);
        }

        $this->landlordModel->update($id, $result['data']);
        $this->logActivity('update', 'landlords', $id, 'Landlord updated');

        $redirect = redirect()->to(base_url('landlords/view/' . $id))->with('success', 'Landlord updated.');
        if ($check['warnings']) {
            $redirect->with('warning', implode(' ', $check['warnings']));
        }

        return $redirect;
    }

    public function delete(int $id)
    {
        $this->assertPerm();
        $this->requireRole('super_admin', 'property_manager', 'facility_manager');

        $this->landlordModel->delete($id);
        $this->logActivity('delete', 'landlords', $id, 'Landlord removed');

        return redirect()->to(base_url('landlords'))->with('success', 'Landlord removed.');
    }

    public function upload_doc(int $id)
    {
        $this->assertPerm();
        $landlord = $this->crud->row('landlords', $id);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        if (! $this->db->tableExists('documents')) {
            return redirect()->back()->with('error', 'Documents module not available.');
        }

        $file = $this->request->getFile('doc_file');
        if (! $file || ! $file->isValid()) {
            return redirect()->back()->with('error', 'Please upload a valid document file.');
        }

        $path = WRITEPATH . 'uploads/documents/';
        if (! is_dir($path)) {
            mkdir($path, 0755, true);
        }
        $newName = $file->getRandomName();
        $file->move($path, $newName);

        $docType = trim((string) $this->request->getPost('doc_type')) ?: 'other';
        $notes   = trim((string) $this->request->getPost('notes'));
        $user    = $this->currentUser();

        $this->db->table('documents')->insert([
            'module'      => 'landlords',
            'ref_id'      => $id,
            'title'       => $file->getClientName(),
            'doc_type'    => $docType,
            'description' => $notes !== '' ? $notes : null,
            'file_path'   => 'uploads/documents/' . $newName,
            'uploaded_by' => $user['id'],
            'created_at'  => date('Y-m-d H:i:s'),
            'updated_at'  => date('Y-m-d H:i:s'),
        ]);

        $this->logActivity('create', 'documents', $id, 'Landlord document uploaded');

        return redirect()->to(base_url('landlords/view/' . $id))->with('success', 'Document uploaded.');
    }

    public function delete_doc(int $docId)
    {
        $this->assertPerm();
        $this->requireRole('super_admin', 'property_manager', 'facility_manager');

        if (! $this->db->tableExists('documents')) {
            return redirect()->back()->with('error', 'Documents module not available.');
        }

        $doc = $this->db->table('documents')->where('id', $docId)->where('module', 'landlords')->get()->getRowArray();
        if (! $doc) {
            return redirect()->back()->with('error', 'Document not found.');
        }

        $landlordId = (int) $doc['ref_id'];
        $this->db->table('documents')->where('id', $docId)->delete();
        $this->logActivity('delete', 'documents', $docId, 'Landlord document deleted');

        return redirect()->to(base_url('landlords/view/' . $landlordId))->with('success', 'Document deleted.');
    }

    public function dismiss_reminder(int $id)
    {
        $this->assertPerm();
        $landlord = $this->crud->row('landlords', $id);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        $key        = trim((string) $this->request->getPost('reminder_key'));
        $reminderId = (int) $this->request->getPost('reminder_id');
        $user       = $this->currentUser();

        if ($key === '' && $reminderId <= 0) {
            return redirect()->back()->with('error', 'Reminder reference missing.');
        }

        $this->landlordModel->dismissReminder($id, $key, (int) $user['id'], $reminderId > 0 ? $reminderId : null);
        $this->logActivity('update', 'landlords', $id, 'Reminder dismissed');

        return redirect()->to(base_url('landlords/view/' . $id))->with('success', 'Reminder dismissed.');
    }

    public function payouts(int $landlordId)
    {
        $this->assertPerm();
        $landlord = $this->landlordModel->findDetail($landlordId);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        return view('landlords/payouts', $this->viewData([
            'title'    => 'Payouts — ' . $landlord['full_name'],
            'landlord' => $landlord,
            'payouts'  => $this->landlordModel->listPayouts($landlordId),
        ]));
    }

    public function create_payout(int $landlordId)
    {
        $this->assertPerm();
        $landlord = $this->landlordModel->findDetail($landlordId);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        if ($this->request->getMethod() === 'post') {
            return $this->storePayout($landlordId, $landlord);
        }

        $properties = $this->landlordModel->propertiesForLandlord($landlordId, $this->scopedFacilityIds());

        return view('landlords/payout_form', $this->viewData([
            'title'           => 'Create Payout',
            'landlord'        => $landlord,
            'properties'      => $properties,
            'payout'          => [],
            'commissionPct'   => (float) ($landlord['commission_pct'] ?? 0),
            'isMarkPaid'      => false,
        ]));
    }

    private function storePayout(int $landlordId, array $landlord): \CodeIgniter\HTTP\RedirectResponse
    {
        if (! $this->db->tableExists('landlord_payouts')) {
            return redirect()->back()->with('error', 'Payout module not available.');
        }

        $post  = $this->request->getPost();
        $check = $this->landlordModel->validatePayoutData($post, $landlord);
        if ($check['errors']) {
            return redirect()->back()->withInput()->with('errors', $check['errors']);
        }

        $gross       = (float) $post['gross_rent'];
        $commissionPct = (float) ($landlord['commission_pct'] ?? 0);
        $commissionIn  = isset($post['commission']) ? (float) $post['commission'] : null;
        $deductions    = (float) ($post['deductions'] ?? 0);
        $amounts       = $this->landlordModel->computePayoutAmounts($gross, $commissionPct, $commissionIn, $deductions);
        $user          = $this->currentUser();

        $this->db->table('landlord_payouts')->insert([
            'company_id'   => $user['company_id'] ?? $landlord['company_id'] ?? null,
            'landlord_id'  => $landlordId,
            'facility_id'  => (int) ($post['property_id'] ?? $post['facility_id']),
            'period_from'  => $post['period_from'],
            'period_to'    => $post['period_to'],
            'gross_rent'   => $gross,
            'commission'   => $amounts['commission'],
            'deductions'   => $amounts['deductions'],
            'net_amount'   => $amounts['net_amount'],
            'status'       => 'pending',
            'notes'        => trim((string) ($post['notes'] ?? '')) ?: null,
            'created_by'   => $user['id'],
            'created_at'   => date('Y-m-d H:i:s'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ]);

        $payoutId = (int) $this->db->insertID();
        $this->logActivity('create', 'landlord_payouts', $payoutId, 'Landlord payout created');

        return redirect()->to(base_url('landlords/view/' . $landlordId))->with('success', 'Payout created.');
    }

    public function mark_payout_paid(int $payoutId)
    {
        $this->assertPerm();

        if (! $this->db->tableExists('landlord_payouts')) {
            return redirect()->to(base_url('landlords'))->with('error', 'Payout module not available.');
        }

        $payout = $this->db->table('landlord_payouts')->where('id', $payoutId)->get()->getRowArray();
        if (! $payout) {
            return redirect()->to(base_url('landlords'))->with('error', 'Payout not found.');
        }

        $landlordId = (int) $payout['landlord_id'];
        $landlord   = $this->landlordModel->findDetail($landlordId);
        if (! $landlord) {
            return redirect()->to(base_url('landlords'))->with('error', 'Landlord not found.');
        }

        if (($payout['status'] ?? '') === 'paid') {
            return redirect()->to(base_url('landlords/view/' . $landlordId))->with('warning', 'Payout is already marked paid.');
        }

        if ($this->request->getMethod() === 'post') {
            $post  = $this->request->getPost();
            $check = $this->landlordModel->validateMarkPaidData($post);
            if ($check['errors']) {
                return redirect()->back()->withInput()->with('errors', $check['errors']);
            }

            $user = $this->currentUser();
            (new LandlordPayoutService($this->db))->markPaidAndJournal($payoutId, (int) $user['id'], [
                'paid_date'       => $post['paid_date'],
                'payment_method'  => trim((string) ($post['payment_method'] ?? '')) ?: null,
                'reference_no'    => trim((string) ($post['reference_no'] ?? '')) ?: null,
            ]);

            $this->logActivity('update', 'landlord_payouts', $payoutId, 'Payout marked paid');

            return redirect()->to(base_url('landlords/view/' . $landlordId))->with('success', 'Payout marked paid and finance entry created.');
        }

        return view('landlords/payout_form', $this->viewData([
            'title'      => 'Confirm Paid',
            'landlord'   => $landlord,
            'properties' => [],
            'payout'     => $payout,
            'commissionPct' => (float) ($landlord['commission_pct'] ?? 0),
            'isMarkPaid' => true,
        ]));
    }

    private function formView(array $row)
    {
        return view('landlords/form', $this->viewData([
            'title'    => 'Landlords',
            'landlord' => $row,
            'isEdit'   => ! empty($row['id']),
        ]));
    }

    private function assertPerm(): void
    {
        $module = PmModules::get('landlords');
        $role   = session()->get('user_role') ?? 'client';
        $rbac   = new RbacService($this->db);
        if (! $rbac->can($role, $module['permission'])) {
            redirect()->to(base_url('dashboard'))
                ->with('error', 'You do not have permission to access landlords.')
                ->send();
            exit;
        }

        $roleId = (int) (session()->get('role_id') ?? 0);
        if ($roleId > 0 && $role !== 'super_admin') {
            $permSvc = new RolePermissionService($this->db);
            if (! $permSvc->can($roleId, 'landlords', 'view')) {
                redirect()->to(base_url('dashboard'))
                    ->with('error', 'Module access denied.')
                    ->send();
                exit;
            }
        }
    }

    /** @return list<int>|null */
    private function scopedFacilityIds(): ?array
    {
        $user = $this->currentUser();
        $role = session()->get('user_role') ?? '';

        return (new PropertyAssignmentService($this->db))->assignedFacilityIds((int) $user['id'], $role);
    }
}
