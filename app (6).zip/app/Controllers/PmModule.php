<?php

namespace App\Controllers;

use App\Services\PmCrudService;
use App\Services\RbacService;
use Config\PmFormFields;
use Config\PmModules;

/**
 * Full CRUD for PM registry modules.
 */
class PmModule extends BaseController
{
  private PmCrudService $crud;

  public function initController(\CodeIgniter\HTTP\RequestInterface $request,
                                 \CodeIgniter\HTTP\ResponseInterface $response,
                                 \Psr\Log\LoggerInterface $logger): void
  {
    parent::initController($request, $response, $logger);
    $this->crud = new PmCrudService($this->db);
  }

  public function index(string $slug)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);

    $table = $module['table'];
    if (! $this->db->tableExists($table)) {
      return $this->registryView($slug, $module, [], true);
    }

    $search  = trim((string) $this->request->getGet('search'));
    $pg      = $this->paginate(25);
    $builder = $this->db->table($table);

    if ($this->db->fieldExists('deleted_at', $table)) {
      $builder->where('deleted_at', null);
    }
    $this->scopeCompany($builder);

    if ($search !== '' && ! empty($module['search'])) {
      $builder->groupStart();
      foreach ($module['search'] as $i => $field) {
        if ($this->db->fieldExists($field, $table)) {
          $builder->{$i === 0 ? 'like' : 'orLike'}($field, $search);
        }
      }
      $builder->groupEnd();
    }

    $orderCol = $this->db->fieldExists('created_at', $table) ? 'created_at' : 'id';
    $total    = (clone $builder)->countAllResults(false);
    $rows     = $builder->orderBy($orderCol, 'DESC')
      ->limit($pg['perPage'], $pg['offset'])
      ->get()->getResultArray();

    return $this->registryView($slug, $module, $rows, false, [
      'search' => $search,
      'page'   => $pg['page'],
      'total'  => $total,
      'perPage'=> $pg['perPage'],
    ]);
  }

  public function create(string $slug)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);

    return $this->formView($slug, $module, []);
  }

  public function store(string $slug)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);
    $table  = $module['table'];

    if (! $this->db->tableExists($table)) {
      return redirect()->back()->with('error', 'Table not installed.');
    }

    $user   = $this->currentUser();
    $result = $this->crud->validateAndBuild($slug, $this->request->getPost(), $user, false);

    if ($result['errors']) {
      return redirect()->back()->withInput()->with('errors', $result['errors']);
    }

    $data = $result['data'];
    $num  = $this->crud->autoNumber($slug, fn ($p, $t, $c) => $this->generateNumber($p, $t, $c));
    if ($num && ! empty($module['number']['field'])) {
      $data[$module['number']['field']] = $num;
    }

    $this->db->table($table)->insert($data);
    $id = (int) $this->db->insertID();
    $this->logActivity('create', $table, $id, "Created {$module['title']} record");

    return redirect()->to(base_url($slug . '/view/' . $id))
      ->with('success', $module['title'] . ' created successfully.');
  }

  public function show(string $slug, int $id)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);

    $row = $this->crud->row($slug, $id);
    if (! $row) {
      return redirect()->to(base_url($slug))->with('error', 'Record not found.');
    }

    $sections = $this->detailSections($slug, $row);
    $extra    = [];

    if ($slug === 'crm' && $this->db->tableExists('crm_activities')) {
      $extra['crmActivities'] = $this->db->table('crm_activities')
        ->where('lead_id', $id)
        ->orderBy('created_at', 'DESC')
        ->limit(10)
        ->get()->getResultArray();
    }

    return view('modules/show', $this->viewData(array_merge([
      'title'    => $module['title'],
      'icon'     => $module['icon'],
      'slug'     => $slug,
      'row'      => $row,
      'sections' => $sections,
      'module'   => $module,
    ], $extra)));
  }

  public function edit(string $slug, int $id)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);

    $row = $this->crud->row($slug, $id);
    if (! $row) {
      return redirect()->to(base_url($slug))->with('error', 'Record not found.');
    }

    return $this->formView($slug, $module, $row);
  }

  public function update(string $slug, int $id)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);
    $table  = $module['table'];

    $row = $this->crud->row($slug, $id);
    if (! $row) {
      return redirect()->to(base_url($slug))->with('error', 'Record not found.');
    }

    $user   = $this->currentUser();
    $result = $this->crud->validateAndBuild($slug, $this->request->getPost(), $user, true);

    if ($result['errors']) {
      return redirect()->back()->withInput()->with('errors', $result['errors']);
    }

    $this->db->table($table)->where('id', $id)->update($result['data']);
    $this->logActivity('update', $table, $id, "Updated {$module['title']} record");

    return redirect()->to(base_url($slug . '/view/' . $id))
      ->with('success', $module['title'] . ' updated successfully.');
  }

  public function delete(string $slug, int $id)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);
    $this->requireRole('super_admin', 'property_manager', 'finance_manager', 'facility_manager');

    $table = $module['table'];
    $row   = $this->crud->row($slug, $id);
    if (! $row) {
      return redirect()->to(base_url($slug))->with('error', 'Record not found.');
    }

    if ($this->db->fieldExists('deleted_at', $table)) {
      $this->db->table($table)->where('id', $id)->update([
        'deleted_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s'),
      ]);
    } else {
      $this->db->table($table)->where('id', $id)->delete();
    }

    $this->logActivity('delete', $table, $id, "Deleted {$module['title']} record");

    return redirect()->to(base_url($slug))->with('success', 'Record deleted.');
  }

  /** Quick status / workflow POST actions */
  public function action(string $slug, int $id, string $action)
  {
    $module = $this->moduleOr404($slug);
    $this->assertPerm($module);
    $table  = $module['table'];
    $row    = $this->crud->row($slug, $id);

    if (! $row) {
      return redirect()->to(base_url($slug))->with('error', 'Record not found.');
    }

    $updates = ['updated_at' => date('Y-m-d H:i:s')];
    $applied = false;

    if ($slug === 'rent-payments') {
      if ($action === 'mark-paid') {
        $updates['status'] = 'paid';
        $updates['payment_date'] = date('Y-m-d');
        $applied = true;
      } elseif ($action === 'postpone') {
        $updates['status'] = 'postponed';
        $applied = true;
      }
    } elseif ($slug === 'cheques') {
      if ($action === 'clear') {
        $updates['status'] = 'cleared';
        $applied = true;
      } elseif ($action === 'bounce') {
        $updates['status'] = 'bounced';
        $applied = true;
      } elseif ($action === 'deposit') {
        $updates['status'] = 'deposited';
        $applied = true;
      }
    } elseif ($slug === 'landlord-payouts' && $action === 'mark-paid') {
      $updates['status'] = 'paid';
      $updates['paid_date'] = date('Y-m-d');
      $applied = true;
    }

    if (! $applied) {
      return redirect()->back()->with('error', 'Unknown action.');
    }

    $this->db->table($table)->where('id', $id)->update($updates);
    $this->logActivity('update', $table, $id, "Action {$action} on {$slug}");

    return redirect()->to(base_url($slug . '/view/' . $id))->with('success', 'Action completed.');
  }

  public function storeCrmActivity(int $leadId)
  {
    $this->moduleOr404('crm');
    $this->assertPerm(PmModules::get('crm'));

    if (! $this->db->tableExists('crm_activities')) {
      return redirect()->back()->with('error', 'CRM activities not installed.');
    }

    $user = $this->currentUser();
    $this->db->table('crm_activities')->insert([
      'lead_id'       => $leadId,
      'activity_type' => $this->request->getPost('activity_type') ?: 'note',
      'subject'       => $this->request->getPost('subject'),
      'description'   => $this->request->getPost('description'),
      'outcome'       => $this->request->getPost('outcome'),
      'created_by'    => $user['id'],
      'created_at'    => date('Y-m-d H:i:s'),
    ]);

    return redirect()->to(base_url('crm/view/' . $leadId))->with('success', 'Activity logged.');
  }

  public function ajaxUnits(int $facilityId)
  {
    $units = [];
    if ($this->db->tableExists('units')) {
      $q = $this->db->table('units')
        ->select('id, unit_number')
        ->where('facility_id', $facilityId)
        ->where('deleted_at', null)
        ->orderBy('unit_number');
      $units = $q->get()->getResultArray();
    }

    return $this->response->setJSON($units);
  }

  private function moduleOr404(string $slug): array
  {
    $module = PmModules::get($slug);
    if (! $module) {
      throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
    }

    return $module;
  }

  private function assertPerm(array $module): void
  {
    $role = session()->get('user_role') ?? 'client';
    $rbac = new RbacService($this->db);
    if (! $rbac->can($role, $module['permission'])) {
      redirect()->to(base_url('dashboard'))
        ->with('error', 'You do not have permission to access that module.')
        ->send();
      exit;
    }
  }

  private function registryView(string $slug, array $module, array $rows, bool $missing, array $meta = [])
  {
    return view('modules/registry', $this->viewData([
      'title'        => $module['title'],
      'icon'         => $module['icon'],
      'slug'         => $slug,
      'columns'      => $module['columns'],
      'rows'         => $rows,
      'filters'      => $meta,
      'tableMissing' => $missing,
    ]));
  }

  private function formView(string $slug, array $module, array $row)
  {
    $user    = $this->currentUser();
    $fkData  = [];
    $sections = PmFormFields::sections($slug);

    foreach ($sections as $section) {
      foreach ($section['fields'] as $field) {
        $name = $field['name'];
        if (isset($fkData[$name])) {
          continue;
        }
        if (($field['type'] ?? '') === 'fk' || ($field['type'] ?? '') === 'fk_user') {
          $fkData[$name] = $this->crud->fkOptions(
            $field,
            $user['company_id'] ? (int) $user['company_id'] : null,
            fn ($q) => $this->scopeCompany($q)
          );
        }
      }
    }

    return view('modules/form', $this->viewData([
      'title'    => $module['title'],
      'icon'     => $module['icon'],
      'slug'     => $slug,
      'row'      => $row,
      'sections' => $sections,
      'fkData'   => $fkData,
      'isEdit'   => ! empty($row['id']),
    ]));
  }

  private function detailSections(string $slug, array $row): array
  {
    $module = PmModules::get($slug);
    $out     = [];

    foreach (PmFormFields::sections($slug) as $section) {
      $fields = [];
      foreach ($section['fields'] as $field) {
        $val = $row[$field['name']] ?? '';
        if (($field['type'] ?? '') === 'checkbox') {
          $val = ! empty($val) ? 'Yes' : 'No';
        }
        if (($field['type'] ?? '') === 'fk' || ($field['type'] ?? '') === 'fk_user') {
          $val = $this->resolveFkLabel($field, $val);
        }
        $fields[] = ['label' => $field['label'], 'value' => (string) $val];
      }
      $out[] = ['label' => $section['label'], 'fields' => $fields];
    }

    if ($module && ! empty($module['number']['field']) && isset($row[$module['number']['field']])) {
      if (! empty($out[0]['fields'])) {
        array_unshift($out[0]['fields'], [
          'label' => 'Number',
          'value' => (string) $row[$module['number']['field']],
        ]);
      }
    }

    return $out;
  }

  private function resolveFkLabel(array $field, mixed $id): string
  {
    if (! $id) {
      return '';
    }
    if (($field['type'] ?? '') === 'fk_user') {
      $r = $this->db->table('users')->select('name')->where('id', (int) $id)->get()->getRowArray();

      return (string) ($r['name'] ?? $id);
    }
    $table = $field['table'] ?? '';
    $disp  = $field['display'] ?? 'name';
    if (! $this->db->tableExists($table)) {
      return (string) $id;
    }
    $r = $this->db->table($table)->select($disp)->where('id', (int) $id)->get()->getRowArray();

    return (string) ($r[$disp] ?? $id);
  }
}
