<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\Honeypot;
use CodeIgniter\Filters\InvalidChars;
use CodeIgniter\Filters\SecureHeaders;

/**
 * FM ERP — Filters Configuration
 *
 * REPLACE your existing app/Config/Filters.php with this file.
 * It keeps all CI4 defaults and adds the 'auth' and 'permission' aliases
 * required by the Work Order / Job Card module.
 */
class Filters extends BaseConfig
{
    /**
     * Configures aliases for Filter classes to
     * make reading things nicer and simpler.
     */
    public array $aliases = [
        // CI4 built-ins — keep these
        'csrf'          => CSRF::class,
        'toolbar'       => DebugToolbar::class,
        'honeypot'      => Honeypot::class,
        'invalidchars'  => InvalidChars::class,
        'secureheaders' => SecureHeaders::class,

        // FM ERP custom filters — required for WO / JC module
        'auth'          => \App\Filters\AuthFilter::class,
        'rbac'          => \App\Filters\RbacFilter::class,
        'workspace'     => \App\Filters\WorkspaceFilter::class,
        'permission'    => \App\Filters\PermissionFilter::class,
        'jwt'           => \App\Filters\JwtFilter::class,
    ];

    /**
     * List of filter aliases that are always
     * applied before and after every request.
     */
    public array $globals = [
        'before' => [
            'csrf' => ['except' => ['api/v1/*']],
            // 'honeypot',
            // 'invalidchars',
        ],
        'after' => [
            'toolbar',
            // 'honeypot',
            // 'secureheaders',
        ],
    ];

    /**
     * List of filter aliases that work on a
     * particular HTTP method (GET, POST, etc.).
     */
    public array $methods = [];

    /**
     * List of filter aliases that should run on any
     * before or after URI patterns.
     */
    public array $filters = [];
}
