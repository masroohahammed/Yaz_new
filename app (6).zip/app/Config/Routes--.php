<?php

use CodeIgniter\Router\RouteCollection;

/**
 * FM ERP — Routes
 *
 * Drop this into app/Config/Routes.php (merge with existing routes).
 * All protected routes use 'auth' + 'permission' filters.
 */

/** @var RouteCollection $routes */

// ============================================================
// Public routes (no auth)
// ============================================================
// Root: redirect to dashboard if logged in, otherwise to login
$routes->get('/', static function () {
    return redirect()->to(session()->get('user_id') ? '/dashboard' : '/auth/login');
});
$routes->get('/auth/login',      'Auth::login');
$routes->post('/auth/login',     'Auth::loginPost');
$routes->get('/auth/logout',     'Auth::logout');

// Public helpdesk submission (allow unauthenticated complaints)
$routes->get('/helpdesk/submit',  'Helpdesk::create');
$routes->post('/helpdesk/submit', 'Helpdesk::store');

// ============================================================
// Authenticated & permission-filtered routes
// ============================================================
$routes->group('', ['filter' => 'auth permission'], function ($routes) {

    // Dashboard
    $routes->get('/dashboard', 'Dashboard::index');

    // --------------------------------------------------------
    // Helpdesk (Stages 1–4)
    // --------------------------------------------------------
    $routes->get('/helpdesk',                           'Helpdesk::index');
    $routes->get('/helpdesk/create',                    'Helpdesk::create');
    $routes->post('/helpdesk',                          'Helpdesk::store');
    $routes->get('/helpdesk/(:num)',                    'Helpdesk::show/$1');
    $routes->post('/helpdesk/(:num)/verify',            'Helpdesk::verify/$1');
    $routes->post('/helpdesk/(:num)/approve',           'Helpdesk::approve/$1');
    $routes->post('/helpdesk/(:num)/convert',           'Helpdesk::convertToWo/$1');

    // --------------------------------------------------------
    // Work Orders (Stages 4–12)
    // --------------------------------------------------------
    $routes->get('/work-orders',                              'WorkOrders::index');
    $routes->get('/work-orders/create',                       'WorkOrders::create');
    $routes->post('/work-orders',                             'WorkOrders::store');
    $routes->get('/work-orders/(:num)',                       'WorkOrders::show/$1');
    $routes->get('/work-orders/(:num)/edit',                  'WorkOrders::edit/$1');
    $routes->post('/work-orders/(:num)/update',               'WorkOrders::update/$1');
    $routes->post('/work-orders/(:num)/assign-supervisor',    'WorkOrders::assignSupervisor/$1');
    $routes->post('/work-orders/(:num)/schedule',             'WorkOrders::schedule/$1');
    $routes->post('/work-orders/(:num)/submit-qc',            'WorkOrders::submitQc/$1');
    $routes->post('/work-orders/(:num)/qc',                   'WorkOrders::approveQc/$1');
    $routes->post('/work-orders/(:num)/close',                'WorkOrders::close/$1');
    $routes->post('/work-orders/(:num)/comment',              'WorkOrders::addComment/$1');
    $routes->post('/work-orders/(:num)/delete',               'WorkOrders::delete/$1');

    // --------------------------------------------------------
    // Job Cards (Stages 6, 7, 9, 11)
    // --------------------------------------------------------
    $routes->get('/job-cards',                          'JobCards::index');
    $routes->get('/job-cards/create/(:num)',            'JobCards::create/$1');
    $routes->post('/job-cards/(:num)',                  'JobCards::store/$1');
    $routes->get('/job-cards/(:num)/print',             'JobCards::printCard/$1');
    $routes->get('/job-cards/(:num)',                   'JobCards::show/$1');
    $routes->post('/job-cards/(:num)/start',            'JobCards::startWork/$1');
    $routes->post('/job-cards/(:num)/complete',         'JobCards::complete/$1');
    $routes->post('/job-cards/(:num)/approve',          'JobCards::approve/$1');

    // --------------------------------------------------------
    // Facilities
    // --------------------------------------------------------
    $routes->get('/facilities',                         'Facilities::index');
    $routes->get('/facilities/create',                  'Facilities::create');
    $routes->post('/facilities',                        'Facilities::store');
    $routes->get('/facilities/(:num)',                  'Facilities::show/$1');
    $routes->get('/facilities/(:num)/edit',             'Facilities::edit/$1');
    $routes->post('/facilities/(:num)/update',          'Facilities::update/$1');
    $routes->post('/facilities/(:num)/delete',          'Facilities::delete/$1');

    // --------------------------------------------------------
    // Assets
    // --------------------------------------------------------
    $routes->get('/assets',                             'Assets::index');
    $routes->get('/assets/create',                      'Assets::create');
    $routes->post('/assets',                            'Assets::store');
    $routes->get('/assets/(:num)',                      'Assets::show/$1');
    $routes->get('/assets/(:num)/edit',                 'Assets::edit/$1');
    $routes->post('/assets/(:num)/update',              'Assets::update/$1');
    $routes->post('/assets/(:num)/delete',              'Assets::delete/$1');

    // --------------------------------------------------------
    // Petty Cash
    // --------------------------------------------------------
    $routes->get('/petty-cash',                         'PettyCash::index');
    $routes->get('/petty-cash/create',                  'PettyCash::create');
    $routes->post('/petty-cash',                        'PettyCash::store');
    $routes->get('/petty-cash/(:num)',                  'PettyCash::show/$1');
    $routes->post('/petty-cash/(:num)/approve',         'PettyCash::approve/$1');
    $routes->post('/petty-cash/(:num)/issue',           'PettyCash::issue/$1');
    $routes->post('/petty-cash/(:num)/reconcile',       'PettyCash::reconcile/$1');
    $routes->post('/petty-cash/(:num)/close',           'PettyCash::close/$1');

    // --------------------------------------------------------
    // Invoices
    // --------------------------------------------------------
    $routes->get('/invoices',                           'Invoices::index');
    $routes->get('/invoices/create',                    'Invoices::create');
    $routes->post('/invoices',                          'Invoices::store');
    $routes->get('/invoices/(:num)',                    'Invoices::show/$1');
    $routes->get('/invoices/(:num)/edit',               'Invoices::edit/$1');
    $routes->post('/invoices/(:num)/update',            'Invoices::update/$1');
    $routes->post('/invoices/(:num)/delete',            'Invoices::delete/$1');
    $routes->post('/invoices/(:num)/record-payment',    'Invoices::recordPayment/$1');

    // --------------------------------------------------------
    // Expenses
    // --------------------------------------------------------
    $routes->get('/expenses',                           'Expenses::index');
    $routes->get('/expenses/create',                    'Expenses::create');
    $routes->post('/expenses',                          'Expenses::store');
    $routes->get('/expenses/(:num)',                    'Expenses::show/$1');
    $routes->post('/expenses/(:num)/approve',           'Expenses::approve/$1');
    $routes->post('/expenses/(:num)/delete',            'Expenses::delete/$1');

    // --------------------------------------------------------
    // Reimbursements
    // --------------------------------------------------------
    $routes->get('/reimbursements',                     'Reimbursements::index');
    $routes->get('/reimbursements/create',              'Reimbursements::create');
    $routes->post('/reimbursements',                    'Reimbursements::store');
    $routes->get('/reimbursements/(:num)',               'Reimbursements::show/$1');
    $routes->post('/reimbursements/(:num)/approve',     'Reimbursements::approve/$1');

    // --------------------------------------------------------
    // Contracts
    // --------------------------------------------------------
    $routes->get('/contracts',                          'Contracts::index');
    $routes->get('/contracts/create',                   'Contracts::create');
    $routes->post('/contracts',                         'Contracts::store');
    $routes->get('/contracts/(:num)',                   'Contracts::show/$1');
    $routes->get('/contracts/(:num)/edit',              'Contracts::edit/$1');
    $routes->post('/contracts/(:num)/update',           'Contracts::update/$1');
    $routes->post('/contracts/(:num)/delete',           'Contracts::delete/$1');

    // --------------------------------------------------------
    // Vendors
    // --------------------------------------------------------
    $routes->get('/vendors',                            'Vendors::index');
    $routes->get('/vendors/create',                     'Vendors::create');
    $routes->post('/vendors',                           'Vendors::store');
    $routes->get('/vendors/(:num)',                     'Vendors::show/$1');
    $routes->get('/vendors/(:num)/edit',                'Vendors::edit/$1');
    $routes->post('/vendors/(:num)/update',             'Vendors::update/$1');

    // --------------------------------------------------------
    // Inventory
    // --------------------------------------------------------
    $routes->get('/inventory',                          'Inventory::index');
    $routes->get('/inventory/create',                   'Inventory::create');
    $routes->post('/inventory',                         'Inventory::store');
    $routes->get('/inventory/(:num)',                   'Inventory::show/$1');
    $routes->post('/inventory/(:num)/adjust',           'Inventory::adjust/$1');

    // --------------------------------------------------------
    // Purchase Orders
    // --------------------------------------------------------
    $routes->get('/purchase-orders',                    'PurchaseOrders::index');
    $routes->get('/purchase-orders/create',             'PurchaseOrders::create');
    $routes->post('/purchase-orders',                   'PurchaseOrders::store');
    $routes->get('/purchase-orders/(:num)',              'PurchaseOrders::show/$1');
    $routes->post('/purchase-orders/(:num)/approve',    'PurchaseOrders::approve/$1');

    // --------------------------------------------------------
    // Inspections
    // --------------------------------------------------------
    $routes->get('/inspections',                        'Inspections::index');
    $routes->get('/inspections/create',                 'Inspections::create');
    $routes->post('/inspections',                       'Inspections::store');
    $routes->get('/inspections/(:num)',                  'Inspections::show/$1');
    $routes->post('/inspections/(:num)/update',         'Inspections::update/$1');

    // --------------------------------------------------------
    // Compliance
    // --------------------------------------------------------
    $routes->get('/compliance',                         'Compliance::index');
    $routes->get('/compliance/create',                  'Compliance::create');
    $routes->post('/compliance',                        'Compliance::store');

    // --------------------------------------------------------
    // Employees & Attendance
    // --------------------------------------------------------
    $routes->get('/employees',                          'Employees::index');
    $routes->get('/employees/create',                   'Employees::create');
    $routes->post('/employees',                         'Employees::store');
    $routes->get('/employees/(:num)',                   'Employees::show/$1');
    $routes->get('/attendance',                         'Attendance::index');
    $routes->post('/attendance/checkin',                'Attendance::checkIn');
    $routes->post('/attendance/checkout',               'Attendance::checkOut');

    // --------------------------------------------------------
    // Reports
    // --------------------------------------------------------
    $routes->get('/reports',                            'Reports::index');
    $routes->get('/reports/work-orders',                'Reports::workOrders');
    $routes->get('/reports/financial',                  'Reports::financial');
    $routes->get('/reports/assets',                     'Reports::assets');

    // --------------------------------------------------------
    // Companies (super_admin only, enforced by PermissionFilter)
    // --------------------------------------------------------
    $routes->get('/companies',                          'Companies::index');
    $routes->get('/companies/create',                   'Companies::create');
    $routes->post('/companies',                         'Companies::store');
    $routes->get('/companies/(:num)',                   'Companies::show/$1');
    $routes->get('/companies/(:num)/edit',              'Companies::edit/$1');
    $routes->post('/companies/(:num)/update',           'Companies::update/$1');

    // --------------------------------------------------------
    // Users
    // --------------------------------------------------------
    $routes->get('/users',                              'Users::index');
    $routes->get('/users/create',                       'Users::create');
    $routes->post('/users',                             'Users::store');
    $routes->get('/users/(:num)/edit',                  'Users::edit/$1');
    $routes->post('/users/(:num)/update',               'Users::update/$1');
    $routes->post('/users/(:num)/delete',               'Users::delete/$1');

    // --------------------------------------------------------
    // Notifications
    // --------------------------------------------------------
    $routes->get('/notifications',                      'Notifications::index');
    $routes->get('/notifications/recent',               'Notifications::recent');
    $routes->get('/notifications/(:num)/read',          'Notifications::markRead/$1');
    $routes->get('/notifications/markAllRead',          'Notifications::markAllRead');

    // --------------------------------------------------------
    // Settings
    // --------------------------------------------------------
    $routes->get('/settings',                           'Settings::index');
    $routes->post('/settings',                          'Settings::update');
});
