<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Permissions;

/**
 * PermissionFilter — checks role-based access before hitting the controller.
 *
 * Register in app/Config/Filters.php aliases:
 *   'permission' => \App\Filters\PermissionFilter::class,
 *
 * Then apply as a route filter:
 *   $routes->group('', ['filter' => 'permission'], function ($routes) { ... });
 */
class PermissionFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $role = session()->get('user_role');

        if (! $role) {
            return redirect()->to('/auth/login');
        }

        // Resolve current controller and method from router
        $router     = service('router');
        $controller = class_basename($router->controllerName()); // e.g. "WorkOrders"
        $method     = $router->methodName();                     // e.g. "index"

        if (! Permissions::can($role, $controller, $method)) {
            if (service('request')->isAJAX()) {
                return service('response')
                    ->setStatusCode(403)
                    ->setJSON(['status' => 'error', 'message' => 'Access denied.']);
            }
            return redirect()->back()->with('error', 'You do not have permission to access that page.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}
}
